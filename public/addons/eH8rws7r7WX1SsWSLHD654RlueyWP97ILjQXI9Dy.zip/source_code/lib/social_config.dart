class SocialConfig {
  static final allow_google_login = false;
  static final allow_facebook_login = false;
  var twitter_consumer_secret = "<your consumer key>";
  var twitter_consumer_key = "<your consumer secret>";
}
